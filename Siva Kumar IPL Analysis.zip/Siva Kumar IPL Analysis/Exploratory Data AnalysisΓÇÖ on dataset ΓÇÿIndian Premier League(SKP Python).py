#!/usr/bin/env python
# coding: utf-8
# Data Analyst - Siva Kumar Paladugu
Exploratory Data Analysis - Sports
Problem Statement: Perform Exploratory Data Analysis on 'Indian Premiere League'

As a sports analysts, find out the most successful teams, players and factors contributing win or loss of a team.

Suggest teams or players a company should endorse for its products.
# # Importing Libraries:

# In[16]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')


# # Loading 1st Dataset

# In[17]:


matches = pd.read_csv("Desktop/ipl/matches.csv")


# In[18]:


matches.head()


# In[19]:


matches.tail()


# # Data Information:

# In[20]:


matches.info()


# In[21]:


matches.shape


# In[22]:


matches.describe()


# # Loading 2nd Dataset

# In[23]:


deliveries = pd.read_csv("Desktop/ipl/deliveries.csv")


# In[24]:


deliveries.head()


# In[25]:


deliveries.tail()


# # Data infromation:

# In[26]:


deliveries.info()


# In[27]:


deliveries.shape


# In[28]:


deliveries.describe()


# Merge 2 datasets for optimal insights

# In[29]:


#merging the 2 datasets
merge = pd.merge(deliveries,matches, left_on='match_id', right_on ='id')
merge.head(2)


# In[30]:


merge.info()


# In[31]:


merge.describe()


# In[32]:


matches.id.is_unique


# Self: The match_id is unique where we are alowed to set it as our Index.

# In[33]:


matches.set_index('id', inplace=True)


# In[34]:


#Summary statistics of matches data
matches.describe(include = 'all')


# # Data Preprocessing
# 
# Self: We Perfrom data preprocessing on matches dataset and make it ready for exploratory data analysis.

# In[35]:


matches.head()


# From Profiling, we identifies as:
# 1. City has missing values
# 2. Umpire 1 and Umpire 2 have one missing values each.
# 3. Team 1 and team 2 has 14 distinct values.
# 4. Umpire 3 has 94% missing values.
# 
# Filling in the missing values of city column
# 
# Find the venues corresponding to which the values of city are empty

# In[36]:


matches[matches.city.isnull()][['city','venue']]


# Self: As all venues are in Dubai Stadium we can fill city missing values with Dubai.

# In[37]:


matches.city = matches.city.fillna('Dubai')


# Self: Umpire 1 and Umpire 2 have missing value each.

# In[38]:


matches[(matches.umpire1.isnull()) | (matches.umpire2.isnull())]


# Self: Umpire 3 Column has appro 92% msising values hence to maintain data quality dropping that column.

# In[39]:


matches = matches.drop('umpire3', axis = 1)


# In[40]:


#city has 33 distinct values while we have 35 venues.
#Let's find out venues grouped by cities to see which cities have multiple venues
city_venue = matches.groupby(['city','venue']).count()['season']
city_venue_df = pd.DataFrame(city_venue)
city_venue_df


# # Observations:
# Bangalore	M Chinnaswamy Stadium	66
# Bengaluru	M Chinnaswamy Stadium	7
# 
# 1. Bangalore and Bengaluru both are in data in which both cities are same.
# 2. Chandigarh and Mohali are same and there is just one stadium Punjab Cricket Association IS Bindra Stadium, Mohali whose value has not been entered correctly. We need to have either Chandigarh or Mohali as well as correct name of the stadium there
# 3. Mumbai has 3 stadiums/venues used for IPL
# 4. Pune has 2 venues for IPL

# In[41]:


#Plotting venues along with cities 
v = pd.crosstab(matches['city'],matches['venue'])
v.replace(v[v!=0],1, inplace = True)

#Adding a column by summing each columns
v['count'] = v.sum(axis = 'columns')
#We will just keep last column = 'count'
b = v['count']

#Plotting
plt.figure(figsize = (20,7))
b.plot(kind = 'bar')
plt.title("Number of stadiums in different cities", fontsize = 25, fontweight = 'bold')
plt.xlabel("City", size = 30)
plt.ylabel("Frequency", size = 30)
plt.xticks(size = 20)
plt.yticks(size = 20)


# # Exploratory Data Analysis:
# 
# Number of Matches played in every season:

# In[42]:


plt.figure(figsize=(15,5))
sns.countplot('season', data = matches)
plt.title("Number of matches played each season",fontsize=18,fontweight="bold")
plt.ylabel("Count", size = 25)
plt.xlabel("Season", size = 25)
plt.xticks(size = 20)
plt.yticks(size = 20)


# 1. All other seasons have matches approximately 58-60 matches.
# 2. 2011- 2013 has more matches in all seasons.

# # How many teams played in each season?

# In[43]:


matches.groupby('season')['team1'].nunique().plot(kind = 'bar', figsize=(15,5))
plt.title("Number of teams participated each season ",fontsize=18,fontweight="bold")
plt.ylabel("Count of teams", size = 25)
plt.xlabel("Season", size = 25)
plt.xticks(size = 15)
plt.yticks(size = 15)


# Self: 10 teams in 2011 and 9 teams in 2012-13. Hence there are more matches Played

# # Venues hosted most number of matches:

# In[45]:


matches.venue.value_counts().sort_values(ascending = True).tail(10).plot(kind = 'barh',figsize=(12,8), fontsize=15, color='green')
plt.title("Venue which has hosted most number of IPL matches",fontsize=18,fontweight="bold")
plt.ylabel("Venue", size = 25)
plt.xlabel("Frequency", size = 25)


#  Self: Eden Gardens in Kolkata hosted most number of IPL Matches followed by Wankede and Chinnaswamy.

# # Team having maximum wins in IPL so far:

# In[46]:


#creating a dataframe with season and winner columns
winning_teams = matches[['season','winner']]


# In[47]:


#dictionaries to get winners to each season
winners_team = {}
for i in sorted(winning_teams.season.unique()):
    winners_team[i] = winning_teams[winning_teams.season == i]['winner'].tail(1).values[0]
    
winners_of_IPL = pd.Series(winners_team)
winners_of_IPL = pd.DataFrame(winners_of_IPL, columns=['team'])


# In[48]:


winners_of_IPL['team'].value_counts().plot(kind = 'barh', figsize = (15,5), color = 'darkblue')
plt.title("Winners of IPL across 11 seasons",fontsize=18,fontweight="bold")
plt.ylabel("Teams", size = 25)
plt.xlabel("Frequency", size = 25)
plt.xticks(size = 15)
plt.yticks(size = 15)


# Note: MI and CSK have both won 3 times each followed by KKR who has won 2 times.
# 

# # Does teams choosed to bat or field first, after winning toss?

# In[50]:


matches['toss_decision'].value_counts().plot(kind='pie', fontsize=14, autopct='%3.1f%%', 
                                               figsize=(10,7), shadow=True, startangle=135, legend=True, cmap='Oranges')

plt.ylabel('Toss Decision')
plt.title('Decision taken by captains after winning tosses')


# Note: 61% times teams decided to field first.

# # How toss decision affects match results?

# In[51]:


matches['toss_win_game_win'] = np.where((matches.toss_winner == matches.winner),'Yes','No')
plt.figure(figsize = (15,5))
sns.countplot('toss_win_game_win', data=matches, hue = 'toss_decision')
plt.title("How Toss Decision affects match result", fontsize=18,fontweight="bold")
plt.xticks(size = 15)
plt.yticks(size = 15)
plt.xlabel("Winning Toss and winning match", fontsize = 25)
plt.ylabel("Frequency", fontsize = 25)


# # Team wise data decision to choose bat or field after winning toss.

# In[52]:


plt.figure(figsize = (25,10))
sns.countplot('toss_winner', data = matches, hue = 'toss_decision')
plt.title("Teams decision to bat first or second after winning toss", size = 30, fontweight = 'bold')
plt.xticks(size = 10)
plt.yticks(size = 15)
plt.xlabel("Toss Winner", size = 35)
plt.ylabel("Count", size = 35)


# 1. Chennai Super Kings who has mostly opted to bat first.And Deccan Chargers and Pune Warriors also show the same trend.
# 2. Most teams field first after winning toss 

# # Which Player's performance that led team's win?

# In[56]:


# MoM= matches['player_of_match'].value_counts()
MoM.head(10).plot(kind = 'bar',figsize=(12,8), fontsize=15, color='black')
plt.title("Top 10 players with most MoM awards",fontsize=18,fontweight="bold")
plt.ylabel("Frequency", size = 25)
plt.xlabel("Players", size = 25)


# 1. Data showing IPL is Batsmens dominated game with most number of MOM's.
# 2. Chris Gayle is most succesful player in the IPL history with Most MOM's.

# # How winning matches by fielding first varies across venues?

# In[58]:


new_matches = matches[matches['result'] == 'normal']   #taking all those matches where result is normal and creating a new dataframe
new_matches['win_batting_first'] = np.where((new_matches.win_by_runs > 0), 'Yes', 'No')
new_matches.groupby('venue')['win_batting_first'].value_counts().unstack().plot(kind = 'barh', stacked = True,
                                                                               figsize=(15,15))
plt.title("How winning matches by fielding first varies across venues?", fontsize=18,fontweight="bold")
plt.xticks(size = 15)
plt.yticks(size = 15)
plt.xlabel("Frequency", fontsize = 25)
plt.ylabel("Venue", fontsize = 25)


# Self: Second Batting gives good results across all venues.

# # Is batting second advantageous across all years?

# In[59]:


plt.figure(figsize = (15,5))
sns.countplot('season', data = new_matches, hue = 'win_batting_first')
plt.title("Is batting second advantageous across all years", fontsize=20,fontweight="bold")
plt.xticks(size = 15)
plt.yticks(size = 15)
plt.xlabel("Season", fontsize = 25)
plt.ylabel("Count", fontsize = 25)


# Self: 2010 and 2015 are the only two years where batting second doesnot give optimal results.

# # Top Run Getters of IPL.

# In[60]:


#let's plot the top 10 run getter so far in IPL
merge.groupby('batsman')['batsman_runs'].sum().sort_values(ascending = False).head(10).plot(kind = 'bar', color = 'red',
                                                                                            figsize = (15,5))
plt.title("Top Run Getters of IPL", fontsize = 20, fontweight = 'bold')
plt.xlabel("Batsmen", size = 25)
plt.ylabel("Total Runs Scored", size = 25)
plt.xticks(size = 12)
plt.yticks(size = 12)


# Self: 
# 1. Virat and Suresh raina are the best performers so far in IPL.
# 2. Except MS. Dhoni all other batters or in top 4 slots in their batting positions.

# # Which batsman has been most consistent among top 10 run getters?

# In[61]:


consistent_batsman = merge[merge.batsman.isin(['SK Raina', 'V Kohli','RG Sharma','G Gambhir',
                                            'RV Uthappa', 'S Dhawan','CH Gayle', 'MS Dhoni',
                                            'DA Warner', 'AB de Villiers'])][['batsman','season','total_runs']]

consistent_batsman.groupby(['season','batsman'])['total_runs'].sum().unstack().plot(kind = 'box', figsize = (15,8))
plt.title("Most Consistent batsmen of IPL", fontsize = 20, fontweight = 'bold')
plt.xlabel("Batsmen", size = 25)
plt.ylabel("Total Runs Scored each season", size = 25)
plt.xticks(size = 15)
plt.yticks(size = 15)


# Self: Median Score of Raina is above all top run getters.

# # Which bowlers have performed the best?

# In[62]:


merge.groupby('bowler')['player_dismissed'].count().sort_values(ascending = False).head(10).plot(kind = 'bar', 
                                                color = 'purple', figsize = (15,5))
plt.title("Top Wicket Takers of IPL", fontsize = 20, fontweight = 'bold')
plt.xlabel("Bowler", size = 25)
plt.ylabel("Total Wickets Taken", size = 25)
plt.xticks(size = 12)
plt.yticks(size = 12)


# Self:
# 1. Malinga has taken the most number of wickets in IPL.
# 2. In top 10 bowlers, 5 are fast and medium pacers while the other 5 are spinners means both varieties are succusful in IPL.
# 3. All 5 spinners are right arm spinners and 2 are leg spinners while 3 are off spinners
# 4. All 5 pacers are right arm pacers so there are more righ arm pacers are used and succeded in IPL.
# 

# # Bowlers with maximum number of extras.

# In[63]:


extra = deliveries[deliveries['extra_runs']!=0]['bowler'].value_counts()[:10]
extra.plot(kind='bar', figsize=(11,6), title='Bowlers who have bowled maximum number of Extra balls')

plt.xlabel('BOWLER')
plt.ylabel('BALLS')
plt.show()

extra = pd.DataFrame(extra)
extra.T


# # Which bowlers have picked up wickets more frequently?

# In[64]:


#strike_rate = balls bowled by wickets taken
balls_bowled = pd.DataFrame(merge.groupby('bowler')['ball'].count())
wickets_taken = pd.DataFrame(merge[merge['dismissal_kind'] != 'no dismissal'].groupby('bowler')['dismissal_kind'].count())
seasons_played = pd.DataFrame(merge.groupby('bowler')['season'].nunique())
bowler_strike_rate = pd.DataFrame({'balls':balls_bowled['ball'],'wickets':wickets_taken['dismissal_kind'],
                          'season':seasons_played['season']})
bowler_strike_rate.reset_index(inplace = True)


# In[65]:


bowler_strike_rate['strike_rate'] = bowler_strike_rate['balls']/bowler_strike_rate['wickets']
def highlight_cols(s):
    color = 'skyblue'
    return 'background-color: %s' % color
#Strike rate for bowlers who have taken more than 50 wickets
best_bowling_strike_rate = bowler_strike_rate[bowler_strike_rate['wickets'] > 50].sort_values(by = 'strike_rate', ascending = True)
best_bowling_strike_rate.head().style.applymap(highlight_cols, subset=pd.IndexSlice[:, ['bowler', 'wickets','strike_rate']])


# # The most successful teams, players & factors contributing win or loss of a team:

# 1. The Mumbai city has hosted the most number of IPL matches.
# 2. Chris Gayle has won the maximum number of player of the match title.
# 3. S. Ravi(Sundaram Ravi) has officiated the most number of IPL matches on-field.
# 4. Eden Gardens has hosted the maximum number of IPL matches.
# 5. If a team wins a toss choose to field first as it has highest probablity of winning.
# 6. Mumbai Indians is the most successful team in IPL and has won the most number of toss.
# 7. There were more matches won by chasing the total(419 matches) than defending(350 matches).
# 8. When defending a total, the biggest victory was by 146 runs(Mumbai Indians defeated Delhi  Daredevils by 146 runs on 06 May 2017 at Feroz Shah Kotla stadium, Delhi).
# 9. When chasing a target, the biggest victory was by 10 wickets(without losing any wickets) and there were 11 such instances.

# # Teams or Players a company should endorse for its products.

# 1. If the franchise is looking for a batsman who could score good amount of runs every match the go for DA Warner, CH Gayle, V Kohli,AB de Villiers,S Dhawan.
# 2. If the franchise is looking for a game changing batsman then go for Chris Gayle, AB deVillers, R Sharma , MS Dhoni.
# 3. If the franchise is looking for a consistant batsman who needs to score good amount of runs then go for V Kohli, S Raina, Rohit Sharma , David Warner.
# 4. If the franchise needs the best finisher in lower order having good strike rate then go for CH Gayle,KA Pollard, DA Warner,SR Watson,BB McCullum.
# 5. If the franchise need a experienced bowler then go for Harbhajan Singh ,A Mishra,PP Chawla ,R Ashwin,SL Malinga,DJ Bravo.
# 6. If the franchise need a wicket taking bowler then go for SL Malinga,DJ Bravo,A Mishra ,Harbhajan Singh, PP Chawla.
# 7. If the franchise need a bowler bowling most number of dot balls then go for Harbhajan Singh,SL Malinga,B Kumar,A Mishra,PP Chawla.

# As a profissional sports analyst this insights gives better insigts for team management to make optimal decisions. Thank you. 
#                                     Siva Kumar Paladugu
#                                     Data analyst
#                                     Sparks foundation intern.

# In[ ]:




